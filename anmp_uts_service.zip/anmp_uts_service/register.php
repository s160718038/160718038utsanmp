<?php
// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "anmp_uts_service");

// Check koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data dari POST request
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$namaDepan = $_POST['nama_depan'];
$namaBelakang = $_POST['nama_belakang'];

// Query untuk insert data ke tabel user
$sql = "INSERT INTO user (username, password, email, nama_depan, nama_belakang) VALUES ('$username', '$password', '$email', '$namaDepan', '$namaBelakang')";

// Eksekusi query
if (mysqli_query($conn, $sql)) {
    echo "Registrasi berhasil";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Tutup koneksi
mysqli_close($conn);
?>
