<?php
// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "anmp_uts_service");

// Check koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil data dari POST request
$username = $_POST['username'];
$password = $_POST['password'];

// Query untuk mencari user dengan username dan password yang cocok
$sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";

// Eksekusi query
$result = mysqli_query($conn, $sql);

// Periksa apakah pengguna ditemukan
if (mysqli_num_rows($result) > 0) {
    // Pengguna ditemukan, kirim respons berhasil
    echo "Login berhasil";
} else {
    // Pengguna tidak ditemukan, kirim respons gagal
    echo "Login gagal, username atau password salah";
}

// Tutup koneksi
mysqli_close($conn);
?>
